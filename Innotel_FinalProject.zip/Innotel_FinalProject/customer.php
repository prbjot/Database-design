<!-- Amardeep Sayila 8754835
Hardik Khetarpal 8769176 
Sapna Sandhu 8712938
Bhanu Prakash Majety 8726463-->

<?php
// database connection code
if(isset($_POST['txtName']))
{
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');
$con = mysqli_connect('localhost', 'root', '','hotel_innotel');

// get the post records

$txtName = $_POST['txtName'];
$txtEmail = $_POST['txtEmail'];
$txtAddress = $_POST['txtAddress'];
$txtPhone = $_POST['txtPhone'];
$txtGender = $_POST['txtGender'];
$txtIdproof = $_POST['txtIdproof'];
$id=0;
$sql_customer = "SELECT MAX(ID) id FROM CUSTOMER";
$result = mysqli_query($con, $sql_customer);
if (mysqli_num_rows($result) == 1) {
	// echo(sql_customer);
	$row = mysqli_fetch_assoc($result);
	  $id=$row["id"]+1;
  } else if (mysqli_num_rows($result) >= 2){
	echo "Returned multiple values";
  }
  
// database insert SQL code
$sql = "INSERT INTO `customer` (`id`, `name`, `address`, `phone_number`, `gender`, `idproof`,`email`) 
VALUES ($id, '$txtName', '$txtAddress', '$txtPhone', '$txtGender', '$txtIdproof','$txtEmail')";
// insert in database 
$rs = mysqli_query($con, $sql);
echo $rs;
if($rs)
{
	header("Location: booking.html");
}
}
else
{
	echo "Are you a genuine visitor?";
}	

?>
