

<?php 

  $con = mysqli_connect('localhost', 'root', '','hotel_innotel');

  //import the fpdf lib
  include_once ('fpdf184/fpdf.php');
  if(isset($con))
  {
  $id_customer=1;
$sql_customer = "SELECT MAX(ID) id FROM CUSTOMER";
$result = mysqli_query($con, $sql_customer);
if (mysqli_num_rows($result) == 1) {
	$row = mysqli_fetch_assoc($result);
	  $id_customer=$row["id"];
  } else if (mysqli_num_rows($result) >= 2){
	echo "Returned multiple values";
  }
  class PDF extends FPDF 
  {
      function Header()
      {
         $this->Image('./logo/innotel logo.jpeg',10,10,50); //print image x, y, width 
         $this->SetFont('Arial','B',15); //Select your font
         $this->Cell(180,0,'Innotel Hotel',0, 0, 'R');
         $this->SetFont('Arial','',13); //Select your font
         $this->Cell(4,15,'250 Regina Road',0, 0, 'R');
         $this->Cell(-17,25,'Vaughan',0, 0, 'R');
         $this->Cell(-5,35,'Ontario, Canada',0, 0, 'C');
         $this->Ln(40);
         $this->SetFont('Arial','B',18); //Select your font
         $this->Cell(180,0,'INVOICE',0, 0, 'C');
         $this->Ln(20);

      }

      function Footer()
      {
          $this->SetY(-30); 
          $this->SetFont('Arial','B',13); //Select your font
          $this->SetFillColor(255, 0, 0);
          $this->Rect(10, 265, 190, 30, 'F');
          $this->SetTextColor(255,255,255);
          $this->Cell(45,30,'Amardeep Sayila',0,0,'C');
          $this->Cell(45,30,'Hardik Khetarpal',0,0,'C');
          $this->Cell(45,30,'Sapna Sandhu',0,0,'C');
          $this->Cell(45,30,'Bhanu Prakash',0,0,'C');

          $this->Ln(5);

          $this->Cell(45,30,'8754835',0,0,'C');
          $this->Cell(45,30,'8769176',0,0,'C');
          $this->Cell(45,30,'8712938',0,0,'C');
          $this->Cell(45,30,'8726463',0,0,'C');


      }
  }

 
$query = mysqli_query($con, "Select * from customer where id=$id_customer")or die("database error:".mysqli_errror($con));
$customer = mysqli_fetch_array($query);
$pdf = new PDF();
$pdf->AddPage();

//SetFonts 
$pdf->SetFont('Arial','B',13); //Set font 
$pdf->Cell(50,0,'Customer Details:',0, 0, 'L');
$pdf->Ln(10);

$pdf->SetFont('Arial','',10); 

$pdf->Cell(130,7,'Customer Name',1,0);
$pdf->Cell(59,7,$customer['name'],1,1);
$pdf->Cell(130,7,'Email',1,0);
$pdf->Cell(59,7,$customer['email'],1,1);
$pdf->Cell(130,7,'Phone No.',1,0);
$pdf->Cell(59,7,$customer['phone_number'],1,1);
$pdf->Cell(130,7,'Address',1,0);
$pdf->Cell(59,7,$customer['address'],1,1);
$pdf->Cell(130,7,'Id Proof',1,0);
$pdf->Cell(59,7,$customer['idproof'],1,1);


$pdf->Ln(10);

$query1 = mysqli_query($con, "Select * from booking where customer_id=$id_customer")or die("database error:".mysqli_errror($con));
$booking = mysqli_fetch_array($query1);

$query2 = mysqli_query($con, "select room_type.type,room_type.fare from room_type INNER JOIN room ON room_type.id_type = room.room_type_id_type INNER JOIN booking ON booking.room_id_room = room.id_room where booking.customer_id=$id_customer")or die("database error:".mysqli_errror($con));
$room = mysqli_fetch_array($query2);

$query3 = mysqli_query($con, "Select DATEDIFF(checkout,checkin) AS dif from booking where customer_id=$id_customer")or die("database error:".mysqli_errror($con));
$diff = mysqli_fetch_array($query3);

$pdf->SetFont('Arial','B',13); //Set font 
$pdf->Cell(50,0,'Booking Details:',0, 0, 'L');
$pdf->Ln(10);

$pdf->SetFont('Arial','',10); 

$pdf->Cell(130,7,'Booking Date',1,0);
$pdf->Cell(59,7,$booking['booking_date'],1,1);
$pdf->Cell(130,7,'Check In',1,0);
$pdf->Cell(59,7,$booking['checkin'],1,1);
$pdf->Cell(130,7,'Check Out',1,0);
$pdf->Cell(59,7,$booking['checkout'],1,1);

$pdf->Cell(130,7,'Nights',1,0);
$pdf->Cell(59,7,$diff['dif'],1,1);

$pdf->Cell(130,7,'Room Type',1,0);
$pdf->Cell(59,7,$room['type'],1,1);
$pdf->Ln(10);

$pdf->Cell(110,7,'Price For ',0,0,'R');
$pdf->Cell(20,7,$room['type'],0,0);
$pdf->Cell(59,7,$room['fare'],0,1,'C');

$pdf->SetFont('Arial','B',12); 
$pdf->Ln(10);
$pdf->Cell(130,7,'To Pay : ',0,0,'R');
$pdf->Cell(49,7,$room['fare']*$diff['dif'],0,1);



  $pdf->Output();
  }
?>

<!-- Amardeep Sayila 8754835
Hardik Khetarpal 8769176 
Sapna Sandhu 8712938
Bhanu Prakash Majety 8726463-->