
<!-- Amardeep Sayila 8754835
Hardik Khetarpal 8769176 
Sapna Sandhu 8712938
Bhanu Prakash Majety 8726463-->

<?php
// database connection code
if(isset($_POST['txtBookingDate']))
{
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');
$con = mysqli_connect('localhost', 'root', '','hotel_innotel');

// get the post records
$txtCheckInDate = $_POST['txtCheckInDate'];
$txtCheckOutDate = $_POST['txtCheckOutDate'];
$txtBookingDate = $_POST['txtBookingDate'];
$txtRoomtype =filter_input(INPUT_POST, 'txtRoomtype');
$id_customer=1;
$id_booking=1;
$sql_customer = "SELECT MAX(ID) id FROM CUSTOMER";
$result = mysqli_query($con, $sql_customer);
if (mysqli_num_rows($result) == 1) {
	$row = mysqli_fetch_assoc($result);
	  $id_customer=$row["id"];
  } else if (mysqli_num_rows($result) >= 2){
	echo "Returned multiple values";
  }
$sql_booking = "SELECT MAX(booking_ID) id FROM BOOKING";
$result = mysqli_query($con, $sql_booking);
if (mysqli_num_rows($result) == 1) {
	$row = mysqli_fetch_assoc($result);
	  $id_booking=$row["id"]+1;
  } else if (mysqli_num_rows($result) >= 2){
	echo "Returned multiple values";
  }
// database insert SQL code
$sql = "INSERT INTO `booking` (`booking_id`, `checkin`, `checkout`, `booking_date`, `room_id_room`,`customer_id`) 
VALUES ($id_booking, '$txtCheckInDate', '$txtCheckOutDate', '$txtBookingDate', '$txtRoomtype','$id_customer')";
// insert in database 
$rs = mysqli_query($con, $sql);
if($rs)
{
	header("Location: success.html");
}
}
else
{
	echo "Are you a genuine visitor?";
}	

?>
