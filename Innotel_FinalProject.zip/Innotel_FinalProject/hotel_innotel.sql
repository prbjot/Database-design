--  Amardeep Sayila 8754835
-- Hardik Khetarpal 8769176 
-- Sapna Sandhu 8712938
-- Bhanu Prakash Majety 8726463

create database hotel_innotel;
USE hotel_innotel ;
drop database hotel_innotel;
-- -----------------------------------------------------
-- Table `hotel_innotel`.`customer`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hotel_innotel`.`customer` ;

CREATE TABLE IF NOT EXISTS `hotel_innotel`.`customer` (
  `id` INT NOT NULL,
  `name` VARCHAR(20) NOT NULL,
  `address` VARCHAR(150) NOT NULL,
  `phone_number` INT NOT NULL,
  `gender` VARCHAR(45) NOT NULL,
  `idproof` VARCHAR(100) NOT NULL,
  `email` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));


-- -----------------------------------------------------
-- Table `hotel_innotel`.`room_type`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hotel_innotel`.`room_type` ;

CREATE TABLE IF NOT EXISTS `hotel_innotel`.`room_type` (
  `id_type` INT NOT NULL,
  `type` VARCHAR(45) NOT NULL,
  `fare` DECIMAL(20,2) NOT NULL,
  PRIMARY KEY (`id_type`));

INSERT INTO `room_type` (`id_type`, `type`, `fare`) VALUES
(1, 'Standard', '100.00'),
(2, 'Deluxe', '200.00'),
(3, 'Joint Room', '300.00'),
(4, 'Connecting Room', '400.00'),
(5, 'Suite', '500.00');


-- -----------------------------------------------------
-- Table `hotel_innotel`.`room`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hotel_innotel`.`room` ;

CREATE TABLE IF NOT EXISTS `hotel_innotel`.`room` (
  `id_room` INT NOT NULL,
  `availability` VARCHAR(45) NOT NULL,
  `room_type_id_type` INT NOT NULL,
  PRIMARY KEY (`id_room`),
  CONSTRAINT `fk_room_room_type1`
    FOREIGN KEY (`room_type_id_type`)
    REFERENCES `hotel_innotel`.`room_type` (`id_type`));

INSERT INTO `room` (`id_room`, `availability`, `room_type_id_type`) VALUES
(1, 'A', 1),
(2, 'A', 2),
(3, 'A', 3),
(4, 'A', 4),
(5, 'A', 5);
-- -----------------------------------------------------
-- Table `hotel_innotel`.`booking`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hotel_innotel`.`booking` ;

CREATE TABLE IF NOT EXISTS `hotel_innotel`.`booking` (
  `booking_id` INT NOT NULL,
  `checkin` DATE NOT NULL,
  `checkout` DATE NOT NULL,
  `booking_date` DATE NOT NULL,
  `customer_id` INT NOT NULL,
  `room_id_room` INT NOT NULL,
  PRIMARY KEY (`booking_id`),
  CONSTRAINT `fk_booking_customer1`
    FOREIGN KEY (`customer_id`)
    REFERENCES `hotel_innotel`.`customer` (`id`),
  CONSTRAINT `fk_booking_room1`
    FOREIGN KEY (`room_id_room`)
    REFERENCES `hotel_innotel`.`room` (`id_room`));


