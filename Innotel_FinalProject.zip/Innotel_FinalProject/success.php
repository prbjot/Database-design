<!-- Amardeep Sayila 8754835
Hardik Khetarpal 8769176 
Sapna Sandhu 8712938
Bhanu Prakash Majety 8726463-->

 <?php
$con = mysqli_connect('localhost', 'root', '','hotel_innotel');

if(isset($con))
{
	header("Location: hotel.php");
}

else
{
	echo "Are you a genuine visitor?";
}	

?>
