// Amardeep Sayila 8754835
// Hardik Khetarpal 8769176 
// Sapna Sandhu 8712938
// Bhanu Prakash Majety 8726463


$(document).ready(function() {
	
	$('#formvalidation').submit (event => {
		var isValid = true;
		var emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;
		var phonePattern = /^(\+?1 ?)?\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
		var namePattern = /^[a-z ,.'-]+$/i;

        // Get the input box values

		var name = $('#txtName').val().trim();
		var email = $('#txtEmail').val().trim();
		var address = $('#txtAddress').val().trim();
        var phone = $('#txtPhone').val().trim();
        var gender = $('#txtGender').val().trim();
        var idproof = $('#txtIdproof').val().trim();

        // Validate Name
		if (name == "") { 
            $("#txtName").next().text("This field is required.");
            isValid = false;
        }
        else if ( !namePattern.test(name) ) {
            $("#txtName").next().text(
                "Please enter a valid name.");
            isValid = false;
        } else {
            $("#txtName").next().text("");
        }
        $("#txtName").val(name);

		// Validate Email Id
		if (email == "") { 
            $("#txtEmail").next().text("This field is required.");
            isValid = false;
        }
        else if ( !emailPattern.test(email) ) {
            $("#txtEmail").next().text(
                "Please enter a valid email Id.");
            isValid = false;
        } else {
            $("#txtEmail").next().text("");
        }
        $("#txtEmail").val(email);

        // Validate address
		if (address == "") { 
            $("#txtAddress").next().text("This field is required.");
            isValid = false;
        }
        else if ( !namePattern.test(address) ) {
            $("#txtAddress").next().text(
                "Please enter a valid name.");
            isValid = false;
        } else {
            $("#txtAddress").next().text("");
        }
        $("#txtAddress").val(address);

		// validate phone
		if (phone == "") { 
            $("#txtPhone").next().text("This field is required.");
            isValid = false;
        }
        else if ( !phonePattern.test(phone) ) {
            $("#txtPhone").next().text(
                "Please enter a valid phone number.");
            isValid = false;
        } else {
            $("#txtPhone").next().text("");
        }
        $("#txtPhone").val(phone);


        // Validate gender
		if (gender == "") { 
            $("#txtGender").next().text("This field is required.");
            isValid = false;
        }
        else if ( !namePattern.test(gender) ) {
            $("#txtGender").next().text(
                "Please enter a valid name.");
            isValid = false;
        } else {
            $("#txtGender").next().text("");
        }
        $("#txtGender").val(gender);


        // Validate idproof
		if (idproof == "") { 
            $("#txtIdproof").next().text("This field is required.");
            isValid = false;
        }
        else if ( !namePattern.test(idproof) ) {
            $("#txtIdproof").next().text(
                "Please enter a valid name.");
            isValid = false;
        } else {
            $("#txtIdproof").next().text("");
        }
        $("#txtIdproof").val(idproof);


		// prevent the default if not valid
		if (isValid == false) {
            event.preventDefault();
        }

	})
}); // end ready